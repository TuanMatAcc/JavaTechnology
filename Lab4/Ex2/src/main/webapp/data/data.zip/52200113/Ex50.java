class Rectangle {
	private float length = 1.0f;
	private float width = 1.0f;
	public Rectangle() {
		
	}
	
	public Rectangle(float length, float width) {
		this.length = length;
		this.width = width;
	}
	
	public float getLength() {
		return length;
	}
	
	public float getWidth() {
		return width;
	}
	
	public void setLength(float len) {
		length = len;
	}
	
	public void setWidth(float wid) {
		width = wid;
	}
	
	public double getArea() {
		return width*length;
	}
	
	public double getPerimeter() {
		return (width+length)*2
	}
	
	public String toString() {
		return "Rectangle[length= " + length + ", width= " + width + "]";
	}
}